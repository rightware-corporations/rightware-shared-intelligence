# RIGHTWARE SI-RD-03A — A0-GLOBAL-02 sealed challenge v0.8

**Status:** PRE-REGISTERED / NOT RUN ON ANY PROVIDER. Research only, synthetic only.

- 82 documents: 70 eligible in `lab:rw:alpha`, 12 foreign in `lab:rw:beta`.
- 56 questions: 12 exact-ID, 18 multilingual, 8 authority-conflict, 6 temporal, 6 unanswerable, 6 foreign scope.
- 44 answerable source-retrieval oracles; 12 no-source questions, assessed only at gateway decision tier.
- No `case_id` filter, no `gold_source_ids` or track labels in public query inputs.
- Encrypted gold oracle is in `fixtures/A0_G02_ORACLES.enc.json`. Its key is **NOT in this public ZIP or the GitHub repository**. Keep the key offline and never add it as a provider input.
- `MANIFEST_A0_G02.json` contains SHA-256 commitments. Any change after comparing engines requires a new benchmark version; don't silently modify this one.
- The previous Kaggle A0 v0.7 result (PGlite Portuguese OR 19/31 hit@2) is FROZEN AS HISTORICAL BASELINE, not directly comparable to this changed dataset.

See `bench/CONTRACT_SUBMISSION_V1.md` and the associated protocol in the RIGHTWARE shared-intelligence repo.

**Do not** call the scoring script with a private key on a Kaggle/engine runner. An evaluator opens the sealed oracle only after retrieving immutable outputs for every tested provider.
