# RIGHTWARE SI-RD-03A — A0-GLOBAL-02 submission contract v1

**Status:** research fixture contract PRE-REGISTERED, not an implementation of PostgreSQL Server, Mem0, or Hindsight.

## Provider runner sees ONLY
- `fixtures/A0_G02_CORPUS.json` (82 synthetic documents)
- `fixtures/A0_G02_QUERIES.json` (56 natural-language questions without `track`, gold source IDs, case identifier or ground-truth metadata)
- Fixed trusted scope `lab:rw:alpha` assigned **out-of-band** by the harness. It MUST NOT be accepted as a user-provided query filter.

Encrypted `fixtures/A0_G02_ORACLES.enc.json` is committed to bind results but MUST NOT be decrypted, loaded, passed as context or inspected by provider adapters. Private decryption key is a separate file not committed and never uploaded to Kaggle with the provider runner.

## Provider output contract
Each engine produces one JSON for the full set of 56 `query_id`s. Example shape:

```json
{
  "schema": "RW_SI_RD03A_A0_G02_SUBMISSION_V1",
  "status": "REAL_EXECUTION",
  "provider": "postgresql_server_ftsv1",
  "mode": "RAW_ENGINE",
  "auth_scope": "lab:rw:alpha",
  "environment": {"engine_version": "OBSERVED", "sha": "PINNED", "hardware": "MEASURED"},
  "results": [
    {"query_id": "G02:Q:0001", "source_ids": ["G02:SRC:0001"], "candidate_count": 1, "gateway": {"decision": "NOT_EVALUATED"}}
  ]
}
```

The full output MUST contain 56 query results and use stable source IDs. Up to five ranked source IDs per query. The example is **not** a valid full benchmark output and does not demonstrate a real run. Do not claim `REAL_EXECUTION` when values are mocked or filled from sealed oracle. Missing or non-applicable tracks must be declared, not converted silently into zero.

## Comparison tiers
- **Tier R (raw retrieval):** engine retrieves sources with same corpus, same external ACL, and same top-k=5; no post-hoc oracle-based filters. Score hit@1/2/5, coverage, language/cohort, scope leakage.
- **Tier G (common gateway):** optional shared, pre-pinned deterministic resolver for exact IDs, source trust/authority, temporal state and abstention. Run IDENTICAL policy against each engine; never count gateway success as engine-native capability. An `ANSWER` must cite `selected_source_id` from retrieved IDs, and decision must be `ANSWER`, `ABSTAIN`, or `DENY`.
- **Tier E (end-to-end):** generated natural-language answers are evaluated separately with human evidence review, after R and G. Not implemented in this package.

## Hard gates and interpretation
1. **0** returned foreign-scope source IDs; any leak => blocked for this run. A fixed lab scope is **not** proof of production authorization/RLS/OIDC.
2. No retrieval match or LLM text may mark a task verified, DONE or approved. Authority and current/as-of are explicitly not raw-engine qualities.
3. Blank retrieval for unknown query is not counted as correct abstention; conversely, nonempty retrieval does not prove hallucination until a decision/answer is made.
4. Separate PostgreSQL Server from PGlite WASM, record versions, pins, data hashes, hardware and exact embedding/model settings. Mem0 `infer=false` and Hindsight `chunks` only when compatible pinned implementations have been confirmed.
5. Label this challenge evaluator-sealed and researcher-authored, **not independently blind**, and synthetic/small. These values cannot justify market-wide superiority.
