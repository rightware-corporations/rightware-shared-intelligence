"""Public smoke contract: no oracle secret or live provider required."""
import unittest, json, hashlib, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(Path(__file__).resolve().parent))
from score_submission import validate_submission,load

class PublicContract(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.manifest=load(BASE/'MANIFEST_A0_G02.json')
  cls.cor=load(BASE/'fixtures/A0_G02_CORPUS.json')
  cls.que=load(BASE/'fixtures/A0_G02_QUERIES.json')
  cls.byid={d['source_id']:d for d in cls.cor['documents']}
  cls.qids=[q['query_id'] for q in cls.que['queries']]
 def test_01_docs(self):self.assertEqual(len(self.byid),82)
 def test_02_eligible(self):self.assertEqual(sum(d['scope_id']==self.manifest['scope'] for d in self.byid.values()),70)
 def test_03_foreign(self):self.assertEqual(sum(d['scope_id']!=self.manifest['scope'] for d in self.byid.values()),12)
 def test_04_queries(self):self.assertEqual(len(self.qids),56)
 def test_05_query_uniqueness(self):self.assertEqual(len(set(self.qids)),56)
 def test_06_no_oracle_leak(self):self.assertTrue(all(set(q)=={'query_id','text','language'} for q in self.que['queries']))
 def test_07_manifest_hashes(self):
  for name,sha in self.manifest['files_sha256'].items():
   self.assertEqual(hashlib.sha256((BASE/name).read_bytes()).hexdigest(),sha)
 def test_08_cipher_alg(self):self.assertEqual(load(BASE/'fixtures/A0_G02_ORACLES.enc.json')['algorithm'],'AES-256-GCM')
 def test_09_no_key_present(self):self.assertFalse((BASE/'private/A0_G02_EVALUATOR_KEY.json').exists())
 def test_10_exact_submission_set(self):
  fake={'schema':'RW_SI_RD03A_A0_G02_SUBMISSION_V1','status':'REAL_EXECUTION','provider':'TEST_FIXTURE','mode':'RAW_ENGINE','auth_scope':'lab:rw:alpha','results':[{'query_id':q,'source_ids':[]} for q in self.qids]}
  self.assertEqual(len(validate_submission(fake,self.qids,self.byid)),56)

if __name__=='__main__':unittest.main(verbosity=2)
