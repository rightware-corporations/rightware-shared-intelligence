# RIGHTWARE SI-RD-03A — A0-GLOBAL-02, protocolo de comparação pré-registado

**Data:** 14-11-2026 · **Estado:** CONTRATO EXPERIMENTAL, NÃO EXECUTADO · **Tipo:** proposta técnica; sem aprovação de fornecedor, produto ou produção.

## 1. Motivação e baseline imutável

O A0 v0.7 foi auditado a partir de execução Kaggle PGlite 0.5.8 (PostgreSQL-WASM 18.3): `portuguese + OR` recuperou fonte esperada em **19/31** Top 2; `simple + OR` em 14/31, `portuguese + AND` em 5/31, e `simple + AND` em 0/31. A experiência mostrou ruído de distractores, vantagem lexical em PT, falha de abstention e possibilidade de um agente não verificado aparecer antes da fonte autoritativa. Estes números são **baseline histórica v0.7**, não são reaproveitados como scores v0.8, e a formulação OR é pós-hoc da v0.6.

As decisões de políticas e segurança G04 do Core, actualmente em engenharia paralela, não estão implicitamente ratificadas por este benchmark.

## 2. Objectivo da nova comparação

Escolher, quando houver evidência suficiente, um mecanismo de **recuperação e gestão de memória** que possa integrar o RIGHTWARE Shared Intelligence Core. Tratar três perguntas **independentes**:

| Dimensão | Pergunta | Instrumento |
|---|---|---|
| R1 — Recuperação | Uma consulta encontra o ID da fonte certa, no âmbito autorizado? | Hit@1/2/5 por exact-ID, cross-language e coortes |
| R2 — Discernimento | O sistema sabe distinguir autoridade e validade temporal? | Gateway comum + oráculos de fonte/estado; **não** penalizar motor nativo por não ser workflow engine |
| R3 — Respostas e controlo | O sistema recusa uma questão sem fundamento e impede exposição fora do âmbito? | Gate de scope (0 fontes alheias), gateway `ANSWER/ABSTAIN/DENY`, revisão manual subsequente |

PostgreSQL Server não é o PGlite WebAssembly; Mem0 e Hindsight devem ser comparados nos seus modos de ingestão pinados e no mesmo **budget** de embeddings/LLM, quando aplicável. Toda vantagem adicional de gateway deve ser reportada separadamente do resultado nativo.

## 3. Entradas congeladas e oracle seal

A0-G02 cria um conjunto **novo** de 82 documentos e 56 queries, estritamente sintético. São 70 documentos elegíveis `lab:rw:alpha` e 12 de outro âmbito `lab:rw:beta`; os IDs das fontes são opacos. As queries públicas têm somente `query_id`, `text`, `language`. Sem gold, `track` ou `case_id`.

Coortes do oráculo cifrado (não disponíveis ao motor): EXACT_ID 12; MULTILINGUAL 18 (consultas cross-language e same-language); AUTHORITY 8; TEMPORAL 6; UNANSWERABLE 6; FORBIDDEN_SCOPE 6. São 44 consultas com fonte esperada e 12 negativas. **O oráculo é cifrado AES-256-GCM no repositório; a chave fica apenas com o avaliador.** O SHA do plaintext está no manifesto. A chave não deve entrar no Kaggle ou nos serviços. Qualquer alteração do corpus/oráculo após os primeiros resultados invalida a comparação e exige nova versão.

**Limitação de cegueira:** o material é *evaluator-sealed*, porém os autores que sintetizaram os exemplos não são independentes da equipa investigadora. Logo não é um holdout externo duplamente cego; uma auditoria por revisores independentes será necessária para qualquer alegação mais forte.

## 4. Fluxo experimental por camadas

1. **Freeze:** confirmar hashes, 56 queries, pin do provider, fontes de pacote, versões e ambiente, aprovado no runbook antes de começar. Não executar um motor e mudar o benchmark em função dos erros observados.
2. **Ingestão idêntica:** cada candidato recebe exatamente os 82 documentos e a autorização `lab:rw:alpha` vinda do harness (não do texto da pergunta). Conservar IDs originais ou manter mapping 1:1 auditável; não fazer inferência/extracção que altere factos na pista A0.
3. **Retrieval engine-only:** cada provider produz um JSON imutável com 56 respostas (`source_ids` ranqueados, Top 5) e logs técnicos. A chave/oráculo permanecem indisponíveis ao motor. Não injectar hints `EXACT_ID`, `AUTHORITY` ou outros rótulos do avaliador nas queries.
4. **Gateway comum separado:** opcionalmente, passar outputs a um adjudicador determinístico que pode reconhecer IDs, proveniência/autoridade, timestamps e abstenção. Identificar este resultado como `COMMON_GATEWAY` e reportar o ganho sobre a pista `RAW_ENGINE`.
5. **Abrir selos e pontuar:** só **depois** da gravação de artefactos imutáveis dos fornecedores, executar 
   `python bench/score_submission.py --submission RAW.json --key <chave-local-privada> --output SCORED.json`. O avaliador verifica SHA dos 3 inputs públicos, GCM e compromisso de plaintext, recusa query faltante, source desconhecida, duplicados, top_k >5 e escopo desconhecido.
6. **Validar e rever:** recalcular hits do raw, investigar mismatches e falsos positivos, rever manualmente pelo menos todos os casos `AUTHORITY`, `TEMPORAL`, `UNANSWERABLE` e `FORBIDDEN_SCOPE`; manter incidentes sem os apagar.

## 5. Métricas e gates

- **Primárias do retrieval:** `hit@1`, `hit@2`, `hit@5` em **44** consultas com fonte gold; quebrar por `track` e `language`; computar candidate coverage como número de queries que retornaram alguma fonte / queries do grupo. Publicar contagens, não apenas percentagens. Em questões com mais de uma fonte gold, um hit significa **pelo menos uma** fonte gold no Top-k; não confundir com recall de todos os factos.
- **Aprovação/estado (quando gateway implementado):** `gateway_accuracy` apenas nos resultados com decisão explícita `ANSWER`, `ABSTAIN`, `DENY`. Para `ANSWER`, `selected_source_id` **deve** estar no output e coincidir com gold; não tomar o primeiro resultado como automaticamente aprovado.
- **Negativas:** as 6 consultas `UNANSWERABLE` e 6 `FORBIDDEN_SCOPE` **não entram no denominador do hit@k**. Candidate non-empty é diagnóstico; só respostas/decisões explícitas suportam métricas de abstenção e negação. Retornar uma fonte irrelevante não é, por si, violação de scope nem prova de hallucination.
- **Segurança:** `foreign_source_count = 0` em todas as 56 queries; qualquer source `lab:rw:beta` devolvida = **RUN BLOCKED**. Este gate é evidência apenas da política **fixa e sintética de laboratório**, não de ACL empresarial, autenticação OIDC/RLS ou consentimento de produção.
- **Integridade:** 56/56 query IDs, zero duplicações/IDs fora do corpus, SHA das fixtures e oráculo verificados, versions/pins reais, saída bruta imutável, clean environment e auditoria manual antes de qualquer escolha. Falha => `INVALID_RUN` ou `NOT_COMPARABLE`.
- **Performance/custo:** tempos medianos/p95 reportados por operação observada no mesmo hardware; registrar ingest time, CPU/RAM, custo de embeddings/modelo, tamanho do índice e memória; sem alegar superioridade por latência WASM versus PostgreSQL servidor.

**Não fixamos já um target arbitrário de 90% para decidir plataforma.** Uma decisão técnica exige primeiro resultados reais, erros por segmento, maturidade, custo de infra, licenças, operações e segurança.

## 6. Matriz de fornecedores (planeada, sem resultados)

| Motor | Modo A0 | Ameaças à comparabilidade | Estado neste checkpoint |
|---|---|---|---|
| PostgreSQL Server | exact lookup + FTS `simple`/`portuguese`, mesma corpus/ACL | SQL/tokenização, não usar oracle case filter | NOT_RUN |
| Mem0 OSS | pin revalidado; `infer=false` em laboratório isolado | embeddings e dependências Ollama; mapeamento de source IDs | NOT_RUN |
| Hindsight | pin revalidado; `retain_extraction_mode=chunks` | ingestão/chunking/recall, proveniência por chunk | NOT_RUN |

Se um participante não disponibiliza fonte auditável, marcar `NON_COMPARABLE` para essa pista, não atribuir zero falsamente. Um sistema híbrido (exact+FTS+vector) pode ser explorado **mais tarde e noutro modo**, sem comparar a pontuação híbrida contra um nativo cru.

## 7. O que não fica autorizado

Sem alterações ao core R1/R2, APIs, migrations, policy G01/G04, modelos produtivos ou retenção; sem dados pessoais/município/cliente; sem deploy; sem PR para `main`; sem integração com JARVIS/PULSE; sem decisão de engine. A palavra `PRE-REGISTERED` representa o congelamento **deste contrato sintético** e não ratificação estratégica do benchmark como padrão de produção.

## 8. Próximas entregas

1. Confirmar o compromisso SHA desta versão no repositório e realizar CI dos ficheiros públicos, sem a chave privada.
2. Criar os três adaptadores reais *isolados* com pins verificados. Executar via sistema externo seguro e recolher logs/ZIPs.
3. Descarregar os outputs imutáveis, avaliá-los offline com a chave; publicar relatórios sanitizados, não outputs privados ou segredo.
4. Aplicar revisão humana a autoridade, temporalidade, negativas e fuga; só então abrir decisão de arquitectura. Se houver mudanças nos exemplos, criar A0-GLOBAL-03, nunca reescrever GLOBAL-02.
