#!/usr/bin/env python3
"""Evaluator-only scorer. Key is never provided to a provider runner.

Example: python bench/score_submission.py --submission provider_run.json --key private/A0_G02_EVALUATOR_KEY.json --output results/reviewed_score.json
"""
import argparse, base64, collections, hashlib, json, zlib
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT=Path(__file__).resolve().parent.parent

def load(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def raw_sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def decrypt_oracles(key_file, sealed_file):
 key=load(key_file); sealed=load(sealed_file)
 if sealed.get('algorithm')!='AES-256-GCM':raise ValueError('Unsupported oracle cipher')
 nonce=base64.b64decode(sealed['nonce_base64']); ciphertext=base64.b64decode(sealed['ciphertext_base64']); aad=base64.b64decode(sealed['aad_base64'])
 plain=AESGCM(bytes.fromhex(key['secret_key_hex'])).decrypt(nonce,ciphertext,aad)
 if sealed.get('compression')=='zlib':plain=zlib.decompress(plain)
 sha=hashlib.sha256(plain).hexdigest()
 if sha!=sealed['oracle_plaintext_sha256'] or sha!=key['oracle_sha256']:
  raise ValueError('Oracle commitment mismatch')
 return json.loads(plain)

def validate_static(corpus,queries,oracle,manifest):
 docs=corpus['documents']; q=queries['queries']; o=oracle['oracles']; ids={v['source_id'] for v in docs}; qids=[v['query_id'] for v in q]
 assert len(docs)==82 and len(ids)==82
 assert len(q)==56 and len(qids)==len(set(qids)) and len(o)==56
 assert len([d for d in docs if d['scope_id']==manifest['scope']])==70
 assert [x['query_id'] for x in o]==qids
 assert all(set(x['gold_source_ids']).issubset(ids) for x in o)
 assert all(all(next(d for d in docs if d['source_id']==s)['scope_id']==manifest['scope'] for s in x['gold_source_ids']) for x in o)
 assert all(set(item)<= {'query_id','text','language'} for item in q)
 assert all('gold_source_ids' not in item and 'case_id' not in item and 'track' not in item for item in q)
 return {v['source_id']:v for v in docs},{v['query_id']:v for v in o},qids

def validate_submission(submission, query_ids, doc_by_id, limit=5):
 if submission.get('schema')!='RW_SI_RD03A_A0_G02_SUBMISSION_V1':raise ValueError('Wrong submission schema')
 if submission.get('status')!='REAL_EXECUTION':raise ValueError('Real-execution status required (mock must never be scored as real)')
 if not submission.get('provider') or not submission.get('mode') in ('RAW_ENGINE','COMMON_GATEWAY'):raise ValueError('Provider/mode required')
 if submission.get('auth_scope')!='lab:rw:alpha':raise ValueError('Unknown fixed auth scope')
 results=submission.get('results');
 if not isinstance(results,list) or len(results)!=len(query_ids):raise ValueError('Missing/duplicate query results')
 seen=[]
 for r in results:
  seen.append(r.get('query_id'))
  sources=r.get('source_ids')
  if not isinstance(sources,list) or len(sources)>limit or len(sources)!=len(set(sources)):
   raise ValueError('Duplicate or excessive returned source IDs')
  if not all(isinstance(s,str) and s in doc_by_id for s in sources):raise ValueError('Unknown source returned')
  gateway=r.get('gateway')
  if gateway is not None:
   if gateway.get('decision') not in ('ANSWER','ABSTAIN','DENY','NOT_EVALUATED'):
    raise ValueError('Unknown gateway decision')
   chosen=gateway.get('selected_source_id')
   if gateway.get('decision')=='ANSWER' and chosen not in sources:
    raise ValueError('ANSWER selection must cite one of the retrieved sources')
   if gateway.get('decision')!='ANSWER' and chosen is not None:
    raise ValueError('Non-answer must not provide selected_source_id')
 if set(seen)!=set(query_ids) or len(set(seen))!=len(query_ids):raise ValueError('Query set mismatch')
 return {r['query_id']:r for r in results}

def score(submission, corpus, queries, oracle, manifest):
 docs,oracle_index,qids=validate_static(corpus,queries,oracle,manifest)
 byid=validate_submission(submission,qids,docs)
 counts=collections.defaultdict(lambda:{'queries':0,'answerable':0,'hits_1':0,'hits_2':0,'hits_5':0,'nonempty':0,'foreign_sources':0,'gateway_evaluated':0,'gateway_correct':0})
 seen_outside=[]; rows=[]
 for q in queries['queries']:
  qid=q['query_id']; truth=oracle_index[qid]; r=byid[qid]; sources=r['source_ids']; gold=set(truth['gold_source_ids']); track=truth['track']; lang=q['language']
  for key in ('TOTAL',f'TRACK:{track}',f'LANG:{lang}',f'TRACK_LANGUAGE:{track}:{lang}'):
   c=counts[key];c['queries']+=1;c['nonempty']+=bool(sources);c['answerable']+=bool(gold)
   for k in (1,2,5):c[f'hits_{k}']+=bool(gold.intersection(sources[:k])) if gold else 0
   c['foreign_sources']+=sum(docs[s]['scope_id']!=manifest['scope'] for s in sources)
   gw=r.get('gateway')
   if gw is not None and gw['decision']!='NOT_EVALUATED':
    c['gateway_evaluated']+=1
    expected=truth['expected_decision']; decision=gw['decision']
    correct=decision==expected
    if expected=='ANSWER':
     correct=correct and gw.get('selected_source_id') in gold
    c['gateway_correct']+=bool(correct)
  row={'query_id':qid,'track':track,'language':lang,'candidate_count_reported':r.get('candidate_count'), 'hit_at_1':bool(gold.intersection(sources[:1])) if gold else None,'hit_at_2':bool(gold.intersection(sources[:2])) if gold else None,'hit_at_5':bool(gold.intersection(sources[:5])) if gold else None, 'scope_violation':any(docs[s]['scope_id']!=manifest['scope'] for s in sources)}
  if row['scope_violation']:seen_outside.append(qid)
  rows.append(row)
 summary={}
 for key,c in counts.items():
  d=dict(c);d.update({f'hit_rate_{k}': (c[f'hits_{k}']/c['answerable'] if c['answerable'] else None) for k in (1,2,5)})
  d['gateway_accuracy']=(c['gateway_correct']/c['gateway_evaluated'] if c['gateway_evaluated'] else None)
  summary[key]=d
 gate='BLOCKED_SCOPE_LEAK' if seen_outside else 'NO_FOREIGN_OUTPUT_OBSERVED_LAB_ONLY'
 return {'schema':'RW_SI_RD03A_A0_G02_EVALUATION_RESULT_V1','classification':'EXPERIMENT_ONLY_NO_PRODUCTION_OR_PROVIDER_SELECTION','provider':submission['provider'],'mode':submission['mode'],'scope_gate':gate,'scope_violation_query_ids':seen_outside,'summary':summary,'row_metrics':rows,'notes':['hit@k is source-identification, not answer accuracy','unknown queries excluded from hit@k denominator but gateway decisions assessed only if provided','authority/temporal decision requires the shared gateway tier, not raw retrieval','zero cross-scope outputs in fixed lab do not validate enterprise identity/ACL']}

def run(args):
 manifest=load(ROOT/'MANIFEST_A0_G02.json')
 for rel,sha in manifest['files_sha256'].items():
  if raw_sha(ROOT/rel)!=sha:raise ValueError(f'Input changed after pre-registration: {rel}')
 corpus=load(ROOT/'fixtures/A0_G02_CORPUS.json');queries=load(ROOT/'fixtures/A0_G02_QUERIES.json')
 oracle=decrypt_oracles(args.key,ROOT/'fixtures/A0_G02_ORACLES.enc.json')
 result=score(load(args.submission),corpus,queries,oracle,manifest)
 Path(args.output).parent.mkdir(parents=True,exist_ok=True)
 Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'scope_gate':result['scope_gate'],'total':result['summary']['TOTAL'],'output':args.output},ensure_ascii=False,indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--submission',required=True);p.add_argument('--key',required=True);p.add_argument('--output',required=True);run(p.parse_args())
